from django.apps import AppConfig


class DishConfig(AppConfig):
    name = 'dish'
    verbose_name = '菜品'
